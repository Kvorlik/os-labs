echo Копирование и удаление файла
mkdir /home/student/dir1
mkdir /home/student/dir1/dir2
cat /home/student/sbs-401/TEXT1.txt > /home/student/dir1/dir2/textnew.txt
rm /home/student/sbs-401/TEXT1.txt
echo Файл скопирован и удален
read
