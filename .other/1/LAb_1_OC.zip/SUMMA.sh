echo Объединение и переименование файлов
cat /home/student/sbs-401/A.txt /home/student/sbs-401/B.txt > /home/student/sbs-401/C.txt
cat /home/student/sbs-401/C.txt
read
mv /home/student/sbs-401/A.txt /home/student/sbs-401/FINA.txt
mv /home/student/sbs-401/B.txt /home/student/sbs-401/FINB.txt
echo Задание выполнено
